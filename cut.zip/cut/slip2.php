<?php
$colors=array("red","red","pink");
foreach($colors as $values)
{
echo "$value <br>";
}