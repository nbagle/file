<?php
function addNumber(int $a,int $b)
{
echo $a+$b;
}
$x=1;
do
{
 echo "The number is :$x<br>";
 $x++;
}
while($x<=5);
$x++;
addNumber(5,"5");
?>