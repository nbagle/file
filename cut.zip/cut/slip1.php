<?php

$marks=76;

if($marks>85)
{
 echo"the grade is O";
}
elseif($marks<=85 && $marks>75)
{
 echo"the grade is A";
}
elseif($marks<=75 && $marks>65)
{
 echo"the grade is B";
}
elseif($marks<=65 && $marks>55)
{
 echo"the grade is C";
}
elseif($marks<=55 && $marks>45)
{
 echo"the grade is D";
}
else
{
 echo"the grade is FAIL";
}
?>

